[최초 작성일시] 2024-10-17
[작성자] 솔루션 2팀 한태훈
* 표준모듈 업데이트 작업 Git Log 검색 툴

1) 날짜 검색 또는 커밋 아이디 검색 기능 사용가능
날짜 검색 기능은 시작 날짜(startDate)부터 끝 날짜(endDate)까지 커밋된 리스트를 모두 출력 (branchName설정 필요)
커밋 아이디 검색 기능은 lastCommitId 와 earlyCommitId 사이의 존재하는 commit들을 모두 출력

2) 전체 유저들 중 검색, author/committer 검색 기능 추가 (id 나 member.properties의 이름으로 검색 가능 대소문자 구분 x)

3) gitconfig.properties 값 설명

git.repoPath = C:\\projects\\ezFlow4Java\\.git (.git 파일이 저장되어있는 경로 .git까지 입력/ 역슬래시 2개씩 입력하거나 /로 폴더 구분)
git.lastCommitId = 0f49286323c967b6bc9886cb9315729d2625316e (커밋 아이디 검색 기능에 사용될 최근 커밋 id)
git.earlyCommitId = 34507dfb22652008ef6970b1a82d49275759f1d9 (커밋 아이디 검색 기능에 사용될 이전 커밋 id)
git.startDate = 2024-10-14 (날짜 검색 기능에 사용될 시작 날짜 yyyy-mm-dd)
git.endDate = 2024-10-15 (날짜 검색 기능에 사용될 끝 날짜 yyyy-mm-dd)
git.branchName = master (브랜치 명 입력. pull 받은 후 사용)

4) member.properties 설명
member.properties의 key값은 committer ID 이고, value값은 팀명 + 이름으로 적음.
committer ID에서 사용되는 띄어쓰기 앞엔 \를 적어야한다.

5) 커밋 메시지의 첫번째 줄은 [분류][유형][voc번호][커밋내용요약] 으로 되어있다 가정하고 엑셀 파일에 내용 코드 작성
커밋 메시지의 첫번째 줄에서 []는 구분자로 사용되니 구분자 이외의 목적으로 사용은 금함.


* 터미널에 옵션에 따라 한글 씹힘 현상 발생 가능.